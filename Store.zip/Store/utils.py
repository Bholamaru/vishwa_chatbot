from datetime import datetime
from .models import InwardChallan2

def create_inwardNumber():
        current_year = datetime.now().year % 100  # e.g., 25
        next_year = (datetime.now().year + 1) % 100  # e.g., 26
        prefix = f"{current_year:02d}{next_year:02d}"  # '2526'
        
        # Start from 0001 to 9999 (max 4-digit counter)
        for counter in range(1, 10000):
            Inward = f"{prefix}{counter:05d}"  # '252600001' ... '252609999'
            
            # Ensure uniqueness in DB
            if not InwardChallan2.objects.filter(InwardF4No=Inward).exists():
                return Inward
        raise ValueError("No available challan numbers left for the current year range.")

from datetime import datetime
from .models import MaterialChallan

def create_challan_no():
    current_year = datetime.now().year % 100
    next_year = (datetime.now().year + 1) % 100
    prefix = f"{current_year:02d}{next_year:02d}"

    for counter in range(1, 10000):
        challan_no = f"{prefix}{counter:05d}"
        if not MaterialChallan.objects.filter(ChallanNo=challan_no).exists():
            return challan_no

    # only raise after all 9999 numbers are used
    raise ValueError("No available challan number left for the current year range.")



from datetime import datetime
from .models import JobworkInwardChallan

def create_jobwork_challan_no():
    current_year = datetime.now().year % 100
    next_year = (datetime.now().year + 1) % 100
    prefix = f"{current_year:02d}{next_year:02d}"

    for counter in range(1, 10000):
        inward_f4_no = f"{prefix}{counter:05d}"
        if not JobworkInwardChallan.objects.filter(InwardF4No=inward_f4_no).exists():
            return inward_f4_no

    raise ValueError("No available challan number left for the current year range.")



from datetime import datetime
from .models  import OpeningStockFG
def create_tm_number():
    current_year = datetime.now().year % 100
    next_year = (datetime.now().year + 1) % 100

    prefix = f"{current_year:02d}{next_year:02d}"  # 2526

    # Start from 00001 to 99999
    for counter in range(1, 100000):
        tm_no = f"{prefix}{counter:05d}"  # 252600001

        # Check uniqueness
        if not OpeningStockFG.objects.filter(tm_no=tm_no).exists():
            return tm_no

    raise ValueError("No available TM numbers left for the current financial year.")


from datetime import datetime
from .models import OpeningStockRM


def create_rm_number():
    current_year = datetime.now().year % 100
    next_year = (datetime.now().year + 1) % 100

    prefix = f"{current_year:02d}{next_year:02d}"

    # Start from 00001 to 99999
    for counter in range(1, 100000):
        rm_no = f"{prefix}{counter:05d}"

        # Check uniqueness
        if not OpeningStockRM.objects.filter(no=rm_no).exists():
            return rm_no

    raise ValueError(
        "No available RM numbers left for the current financial year."
    )


from datetime import datetime
from .models import DeliveryChallan


def create_dc_number():
    now = datetime.now()

    # Financial year: April to March
    if now.month >= 4:
        current_year = now.year % 100
        next_year = (now.year + 1) % 100
    else:
        current_year = (now.year - 1) % 100
        next_year = now.year % 100

    prefix = f"DC-{current_year:02d}{next_year:02d}"

    # Find highest number for current financial year
    last_challan = (
        DeliveryChallan.objects
        .filter(dc_series__startswith=prefix)
        .order_by("-dc_series")
        .first()
    )

    if last_challan and last_challan.dc_series:
        last_number = int(last_challan.dc_series[-5:])
        next_number = last_number + 1
    else:
        next_number = 1

    if next_number > 99999:
        raise ValueError(
            "No available Delivery Challan numbers for this financial year."
        )

    return f"{prefix}{next_number:05d}"